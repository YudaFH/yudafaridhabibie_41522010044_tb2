package com.example.tb2_yudafaridhabibie.features.student_crud;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
